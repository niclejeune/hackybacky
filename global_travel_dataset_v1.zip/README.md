# Global Travel Dataset (Starter Pack)
Generated: 2025-09-29

This bundle contains a structured, scalable dataset for 100+ major tourist destinations worldwide.

## Files
- `all_destinations.json`: All destinations in one JSON array.
- `countries.json`: Only country-level destinations.
- `cities_regions.json`: City, region, and island entries.
- `schema.json`: JSON Schema describing the structure.
- `all_destinations.csv`: Flattened table for quick spreadsheet use.

## How this differs from the sample (France)
**Changes made for scalability**:
1. `region_type` added — supports `country | city | region | island` so entries like Bali, Santorini, or Kruger can be modeled.
2. `flag` renamed to `emoji_flag` and made **optional** because not all cities/regions have distinct flags.
3. `metadata` split into `{ "highlights": [], "keywords": [] }` (kept simple & consistent across types).
4. `internet` expanded with `avg_speed_mbps` and `availability` fields useful for digital nomads (left `null` when uncertain).
5. Added `food_drink`, `budget`, and `best_time` to cover practical planning info at-a-glance.
6. Language normalized to avoid overly-specific or fast-stale claims; specifics can be enriched later per destination.

## Sources & Methodology
This starter set synthesizes commonly-agreed travel norms from:
- Community tips on Reddit (e.g., r/travel, r/solotravel).
- Train and transit planning best practices from Seat61 for intercity rail in many countries.
- Nomad and backpacker resources for internet availability patterns and budget ranges.
- General destination themes found across major travel guides and tourism boards.

The content aims to be **conservative and durable**. For high-volatility details (exact SIM brand promos, precise prices, temporary closures),
please verify locally and update entries as needed.

## Notes
- "Must-try" foods and highlights are illustrative, not exhaustive.
- Budget lines are intentionally non-numeric to avoid stale prices; customize per itinerary and season.
- Feel free to add `cities`, `areas`, or more granular keys under `metadata` if your pipeline benefits from it.
